let valor = 10

let subtrair = 2
let multiplicar = 10
let dividir = 1.25
let soma = 3

function subtracao(n1,n2){
    return n1-n2;

}

function multiplicacao(n1,n2){
    return n1*n2;

}

function divisao(n1,n2){
    return n1/n2;

}

function somar(n1,n2){
    return n1+n2;

}

var fim=subtracao(valor,subtrair)
fim=multiplicacao(fim,multiplicar)
fim=divisao(fim,dividir)
fim=somar(fim,soma)

console.log(fim)